#include "ClockWgt.h"

ClockWgt::ClockWgt(QWidget *parent) : QWidget(parent)
{
    
}
