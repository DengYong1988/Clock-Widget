#include "ClockWgt.h"
#include <QPainter>
#include <QResizeEvent>
#include <QTime>
#include <QTimer>
#include <qmath.h>

/************************ ClockWgt *************************/
ClockWgt::ClockWgt(QWidget *parent)
    : QWidget(parent)
{
    initData();
}

ClockWgt::~ClockWgt()
{
    if (m_timer) {
        if (m_timer->isActive())
            m_timer->stop();
        
        m_timer->deleteLater();
        m_timer = nullptr;
    }
}

ClockWgt::SPart::SPart()
    : width(0)
{
    grad.setSpread(QGradient::PadSpread);
}

void ClockWgt::initData()
{
    m_outerFrame.grad.setColorAt(0.9, QColor(250, 36, 66));
    m_outerFrame.grad.setColorAt(0.95, QColor(250, 36, 66, 235));
    m_outerFrame.grad.setColorAt(1, QColor(250, 36, 66, 96));
    m_outerFrame.width = 20;
    
    m_innerFrame.grad.setColorAt(0.8, QColor(200, 200, 200));
    m_innerFrame.grad.setColorAt(1, QColor(235, 235, 245));
    m_innerFrame.width = 10;
    
    m_bkgPart.grad.setColorAt(0, QColor(223, 231, 254));
    m_bkgPart.grad.setColorAt(0.2, QColor(238, 238, 250));
    m_bkgPart.grad.setColorAt(0.8, QColor(238, 238, 250));
    m_bkgPart.grad.setColorAt(0.9, QColor(213, 218, 254));
    m_bkgPart.grad.setColorAt(1, QColor(213, 218, 254));
    
    m_needleRadius = 10;
    m_needleGrad.setSpread(QGradient::PadSpread);
    m_needleGrad.setRadius(20);
    m_needleGrad.setCenter(0, 0);
    m_needleGrad.setFocalPoint(0, 0);
    m_needleGrad.setColorAt(0, QColor(220, 220, 230));
    m_needleGrad.setColorAt(1, QColor(20, 20, 20));
    
    m_timescaleClr.setRgb(7, 7, 9);
    m_timeDigitClr.setRgb(7, 7, 9);
    
    m_timeDigitFont.setFamily("Arial");
    m_timeDigitFont.setPixelSize(44);
    m_timeDigitFont.setWeight(QFont::Bold);

    m_timer = new QTimer(this);
    m_timer->setInterval(1000);
    m_timer->start();
    
    connect(m_timer, &QTimer::timeout, this, [this] {
        this->update();
    });
}

void ClockWgt::resetGradient(QRadialGradient &grad, qreal radius)
{
    grad.setCenter(radius, radius);
    grad.setFocalPoint(radius, radius);
    grad.setCenterRadius(radius);    
}

void ClockWgt::updatePath()
{
    int diameter = qMin(width(), height());
    int offset = m_outerFrame.width;
    
    m_outerFrame.path.addEllipse(QRectF(0, 0, diameter, diameter));
    diameter -= 2 * m_outerFrame.width;
    m_outerFrame.path.addEllipse(QRectF(offset, offset, diameter, diameter));
    
    m_innerFrame.path.addEllipse(QRectF(offset, offset, diameter, diameter));
    offset += m_innerFrame.width;
    diameter -= 2 * m_innerFrame.width;
    m_innerFrame.path.addEllipse(QRectF(offset, offset, diameter, diameter));
    
    m_bkgPart.path.addEllipse(QRectF(offset, offset, diameter, diameter));
    
    m_hourPath.addRoundedRect(-20, -5, 140, 10, 4, 4);
    m_minutePath.addRoundedRect(-20, -4, 200, 8, 4, 4);
    
    m_secondPath.moveTo(-40, 0);
    m_secondPath.lineTo(-36, -4);
    m_secondPath.lineTo(0, -2);
    m_secondPath.lineTo(180, 0);
    m_secondPath.lineTo(0, 2);
    m_secondPath.lineTo(-36, 4);
    m_secondPath.lineTo(-40, 0);
}

void ClockWgt::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.setRenderHint(QPainter::TextAntialiasing, true);
    
    drawBkg(painter);
    drawHand(painter);
}

void ClockWgt::drawBkg(QPainter &painter)
{
    painter.fillPath(m_outerFrame.path, m_outerFrame.grad);
    painter.fillPath(m_innerFrame.path, m_innerFrame.grad);
    painter.fillPath(m_bkgPart.path, m_bkgPart.grad);
    
    const qreal radius = qMin(0.5 * width(), 0.5 * height());
    QPen pen(m_timescaleClr);
    m_transform.reset();
    
    for (int i = 0; i < 60; ++i) {
        int len = 6;
        if (0 == (i % 5)) {
            pen.setWidthF(3.0);
        } else {
            pen.setWidthF(1.0);
        }
        
        painter.setPen(pen);
        
        qreal innerRadius = radius - m_outerFrame.width - m_innerFrame.width - 10 - len;
        qreal xPos = radius + innerRadius * qCos(2 * M_PI * 6 * i / 360);
        qreal yPos = radius - innerRadius * qSin(2 * M_PI * 6 * i / 360);
        m_transform.translate(xPos, yPos);
        m_transform.rotate(-6 * i);
        painter.setTransform(m_transform);
        painter.drawLine(QPoint(-len, 0), QPoint(len, 0));
        m_transform.reset();
    }
    
    pen.setColor(m_timeDigitClr);
    painter.setPen(pen);
    painter.setFont(m_timeDigitFont);
    
    for (int i = 1; i <= 12; ++i) {
        QFontMetrics fm(m_timeDigitFont);
        QString text = QString::number(i);
        
        qreal innerRadius = radius - m_outerFrame.width - m_innerFrame.width - 10 - 36;
        qreal angle = 30 * i - 90;
        qreal xPos = radius + innerRadius * qCos(2 * M_PI * angle / 360);
        qreal yPos = radius + innerRadius * qSin(2 * M_PI * angle / 360);

        m_transform.translate(xPos, yPos);
        painter.setTransform(m_transform);
        painter.drawText(-fm.horizontalAdvance(text) / 2, fm.height() / 2 - fm.descent(), text);
        m_transform.reset();
    }
}

void ClockWgt::drawHand(QPainter &painter)
{
    const qreal radius = qMin(0.5 * width(), 0.5 * height());
    const QTime &dtCurr = QTime::currentTime();
    
    m_transform.reset();
    m_transform.translate(radius, radius);
    
    int h = dtCurr.hour();
    int m = dtCurr.minute();
    int s = dtCurr.second();
    m_transform.rotate(30 * h - 90 + 0.5 * m);
    painter.setTransform(m_transform);
    painter.fillPath(m_hourPath, Qt::black);
    
    m_transform.reset();
    m_transform.translate(radius, radius);
    m_transform.rotate(6 * m - 90);
    painter.setTransform(m_transform);
    painter.fillPath(m_minutePath, Qt::black);
    
    m_transform.reset();
    m_transform.translate(radius, radius);
    m_transform.rotate(6 * s - 90);
    painter.setTransform(m_transform);
    painter.fillPath(m_secondPath, Qt::red);
    
    m_transform.reset();
    m_transform.translate(radius, radius);
    painter.setTransform(m_transform);
    m_transform.reset();
    
    painter.setBrush(m_needleGrad);
    painter.setPen(Qt::transparent);
    painter.drawEllipse(QPoint(0, 0), m_needleRadius, m_needleRadius);
}

void ClockWgt::resizeEvent(QResizeEvent *event)
{
    if (event) {
        const QSize &size = event->size();
        qreal radius = qMin(0.5 * size.width(), 0.5 * size.height());
        
        resetGradient(m_outerFrame.grad, radius);
        resetGradient(m_innerFrame.grad, radius);
        resetGradient(m_bkgPart.grad, radius);
        
        updatePath();
    }
    
    QWidget::resizeEvent(event);
}
