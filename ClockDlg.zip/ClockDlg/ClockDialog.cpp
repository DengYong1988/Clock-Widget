#include "ClockDialog.h"
#include "ClockWgt.h"
#include "DigitalWatchWgt.h"
#include <QPainter>
#include <QVBoxLayout>
#include <QDebug>

ClockDialog::ClockDialog(QWidget *parent)
    : QDialog(parent)
{
    initUi();
    initLayout();
}

ClockDialog::~ClockDialog()
{
}

void ClockDialog::initUi()
{
    this->setFixedSize(600, 800);
    
    m_clockWgt = new ClockWgt(this);
    m_clockWgt->setFixedSize(500, 500);
    
    m_watchWgt = new DigitalWatchWgt(true, this);
    m_watchWgt->setBackground(QColor(32, 32, 32));
    m_watchWgt->setNumSize(QSizeF(50, 100));
}

void ClockDialog::initLayout()
{
    QVBoxLayout *lay = new QVBoxLayout(this);
    lay->setMargin(32);
    lay->setSpacing(32);
    lay->addWidget(m_clockWgt, 0, Qt::AlignCenter);
    lay->addWidget(m_watchWgt, 0, Qt::AlignCenter);
    lay->addStretch();
}

void ClockDialog::paintEvent(QPaintEvent *event)
{
    //qDebug() << Q_FUNC_INFO;
    QDialog::paintEvent(event);
}

