#include "ClockDialog.h"
#include "ClockBkgWgt.h"
#include <QHBoxLayout>

ClockDialog::ClockDialog(QWidget *parent)
    : QDialog(parent)
{
    initUi();
    initLayout();
}

ClockDialog::~ClockDialog()
{
}

void ClockDialog::initUi()
{
    this->setFixedSize(800, 600);
    
    m_clockBkgWgt = new ClockBkgWgt(this);
    m_clockBkgWgt->setFixedSize(500, 500);
}

void ClockDialog::initLayout()
{
    QHBoxLayout *lay = new QHBoxLayout(this);
    lay->setMargin(32);
    lay->setSpacing(32);
    lay->addWidget(m_clockBkgWgt);
}

