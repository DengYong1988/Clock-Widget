#ifndef CLOCKDIALOG_H
#define CLOCKDIALOG_H

#include <QDialog>

class ClockWgt;
class DigitalWatchWgt;

class ClockDialog : public QDialog
{
    Q_OBJECT    
public:
    ClockDialog(QWidget *parent = nullptr);
    ~ClockDialog();
    
private:
    void initUi();
    void initLayout();
    
protected:
    void paintEvent(QPaintEvent *event) Q_DECL_OVERRIDE;
    
private:
    ClockWgt        *m_clockWgt = nullptr;
    DigitalWatchWgt *m_watchWgt = nullptr;
};
#endif // CLOCKDIALOG_H
