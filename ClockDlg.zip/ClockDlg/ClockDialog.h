#ifndef CLOCKDIALOG_H
#define CLOCKDIALOG_H

#include <QDialog>

class ClockBkgWgt;

class ClockDialog : public QDialog
{
    Q_OBJECT    
public:
    ClockDialog(QWidget *parent = nullptr);
    ~ClockDialog();
    
private:
    void initUi();
    void initLayout();
    
private:
    ClockBkgWgt     *m_clockBkgWgt = nullptr;
};
#endif // CLOCKDIALOG_H
