#ifndef DIGITALWATCHWGT_H
#define DIGITALWATCHWGT_H

#include <QWidget>

const int kNumCount = 6;            // 时、分、秒数字数
const int kLineCount = 7;           // 数字8的线条数

class QTimer;

class DigitalWatchWgt : public QWidget
{
    Q_OBJECT
public:
    explicit DigitalWatchWgt(bool isShowSecond, QWidget *parent = nullptr);
    ~DigitalWatchWgt();
    
    void setFixedSize(const QSize &size);
    void setFixedSize(int w, int h);
    
    void setMargin(const QMargins &margin);
    void setNumSpacing(int spacing);
    void setColonSpacing(int spacing);
    
    // 设置组件边框
    void setBorder(qreal border);
    
    // 设置线条之间的偏移量
    void setLineOffset(qreal offset);
    
    // 设置边框颜色
    void setBorderColor(const QColor &borColor);
    
    // 设置组件圆角
    void setBorderRadius(qreal borRadius);
    
    // 设置背景色
    void setBackground(const QColor &bkg);
    
    // 设置数字显示的颜色
    void setNumColor(const QColor &lightColor, const QColor &darkColor);
    
    // 设置数字显示的尺寸
    void setNumSize(const QSizeF &size);
    
    // 设置数字边框粗细
    void setNumBorder(qreal border);
    
    // 设置冒号点宽度
    void setDotWidth(qreal dotWid);
    
private:
    void initData();
    void adaptSize();
    void adjustPos();
    void calcLinePath();
    
protected:
    void paintEvent(QPaintEvent *event) Q_DECL_OVERRIDE;
    
    void drawBackground(QPainter &painter);
    void drawNumber(QPainter &painter, const QChar &num);
    void fillLinePath(QPainter &painter, bool *isDarkColor);
    void drawColon(QPainter &painter, const QRectF &rf);
    
private:
    struct SNumber {
        QChar       m_text;
        qreal       m_topX;
        qreal       m_topY;
        
        explicit SNumber();
        explicit SNumber(const QChar &text);
    };
    
private:
    bool            m_isShowSecond;     // 是否显示秒数
    QMargins        m_margin;
    int             m_numSpacing;       // 数字之间的间距
    int             m_colonSpacing;     // 数字和冒号之间的间距
    qreal           m_border;           // 组件边框
    qreal           m_borRadius;        // 圆角
    qreal           m_lineOffset;       // 线条之间的偏移量
    
    QColor          m_bkgColor;         // 背景色
    QColor          m_borColor;         // 边框色
    QColor          m_numLightColor;    // 数字浅色
    QColor          m_numDarkColor;     // 数字深色
    QSizeF          m_numSize;          // 数字尺寸
    qreal           m_numBorder;        // 数字边框粗细
    qreal           m_dotWid;           // 冒号点宽度
    QRectF          m_rfColon[2];       // 冒号的位置
    
    QTimer          *m_timer = nullptr;
    SNumber         m_number[kNumCount];// 时分秒数字
    QPainterPath    m_linePath[kLineCount];
    QTransform      m_tfDrawing;
};

#endif // DIGITALWATCHWGT_H
