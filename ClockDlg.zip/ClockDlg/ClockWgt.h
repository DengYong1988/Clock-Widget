#ifndef CLOCKWGT_H
#define CLOCKWGT_H

#include <QWidget>

class QTimer;

/************************ ClockWgt *************************/
class ClockWgt : public QWidget
{
    Q_OBJECT
public:
    explicit ClockWgt(QWidget *parent = nullptr);
    ~ClockWgt();
    
private:
    void initData();
    void resetGradient(QRadialGradient &grad, qreal radius);
    void updatePath();
    
protected:
    void paintEvent(QPaintEvent *event) Q_DECL_OVERRIDE;
    void drawBkg(QPainter &painter);        // 绘制背景
    void drawHand(QPainter &painter);       // 绘制时分秒
    
    void resizeEvent(QResizeEvent *event) Q_DECL_OVERRIDE;
    
private:
    // 钟表的局部
    struct SPart {
        QRadialGradient     grad;       // 背景色
        QPainterPath        path;       // 路径
        int                 width;      // 宽度
        
        SPart();
    };

    SPart       m_outerFrame;           // 钟表的外边框
    SPart       m_innerFrame;           // 钟表内边框
    SPart       m_bkgPart;              // 钟表背景部分
    
    QTimer      *m_timer = nullptr;
    
    QColor      m_timescaleClr;         // 时间刻度颜色
    QColor      m_timeDigitClr;         // 时间数字颜色
    QFont       m_timeDigitFont;        // 时间数字字体
    
    QTransform      m_transform;        // 绘图时的坐标转换
    QRadialGradient m_needleGrad;       // 图针的背景
    int             m_needleRadius;     // 图针的半径
    QPainterPath    m_hourPath;         // 时钟路径
    QPainterPath    m_minutePath;       // 分钟路径
    QPainterPath    m_secondPath;       // 秒钟路径
};

#endif // CLOCKWGT_H
