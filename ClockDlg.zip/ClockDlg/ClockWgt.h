#ifndef CLOCKWGT_H
#define CLOCKWGT_H

#include <QWidget>

class ClockWgt : public QWidget
{
    Q_OBJECT
public:
    explicit ClockWgt(QWidget *parent = nullptr);
    
signals:
    
};

#endif // CLOCKWGT_H
