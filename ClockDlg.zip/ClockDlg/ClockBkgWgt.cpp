#include "ClockBkgWgt.h"
#include <QPainter>
#include <QResizeEvent>
#include <qmath.h>
#include <QTime>
#include <QTimer>
#include <QDebug>

ClockBkgWgt::ClockBkgWgt(QWidget *parent) : QWidget(parent)
{
    initData();
}

ClockBkgWgt::~ClockBkgWgt()
{
    if (m_timer) {
        if (m_timer->isActive())
            m_timer->stop();
        
        m_timer->deleteLater();
        m_timer = nullptr;
    }
}

ClockBkgWgt::SPart::SPart()
    : width(0)
{
    grad.setSpread(QGradient::PadSpread);
}

void ClockBkgWgt::initData()
{
    m_outerFrame.grad.setColorAt(0.9, QColor(250, 36, 66));
    m_outerFrame.grad.setColorAt(0.95, QColor(250, 36, 66, 235));
    m_outerFrame.grad.setColorAt(1, QColor(250, 36, 66, 96));
    m_outerFrame.width = 20;
    
    m_innerFrame.grad.setColorAt(0.8, QColor(200, 200, 200));
    m_innerFrame.grad.setColorAt(1, QColor(235, 235, 245));
    m_innerFrame.width = 10;
    
    m_bkgPart.grad.setColorAt(0, QColor(223, 231, 254));
    m_bkgPart.grad.setColorAt(0.2, QColor(238, 238, 250));
    m_bkgPart.grad.setColorAt(0.8, QColor(238, 238, 250));
    m_bkgPart.grad.setColorAt(0.9, QColor(213, 218, 254));
    m_bkgPart.grad.setColorAt(1, QColor(213, 218, 254));
    
    m_timescaleClr.setRgb(7, 7, 9);
    m_timeDigitClr.setRgb(7, 7, 9);
    
    m_timeDigitFont.setFamily("Arial");
    m_timeDigitFont.setPixelSize(44);
    m_timeDigitFont.setWeight(QFont::Bold);
    
    m_timer = new QTimer(this);
    m_timer->setInterval(1000);
    m_timer->start();
    
    connect(m_timer, &QTimer::timeout, this, [this] {
        this->update();
    });
}

void ClockBkgWgt::resetGradient(QRadialGradient &grad, qreal radius)
{
    grad.setCenter(radius, radius);
    grad.setFocalPoint(radius, radius);
    grad.setCenterRadius(radius);
}

void ClockBkgWgt::updatePath()
{
    int diameter = qMin(width(), height());
    int offset = m_outerFrame.width;
    
    m_outerFrame.path.addEllipse(QRectF(0, 0, diameter, diameter));
    diameter -= 2 * m_outerFrame.width;
    m_outerFrame.path.addEllipse(QRectF(offset, offset, diameter, diameter));
    
    m_innerFrame.path.addEllipse(QRectF(offset, offset, diameter, diameter));
    offset += m_innerFrame.width;
    diameter -= 2 * m_innerFrame.width;
    m_innerFrame.path.addEllipse(QRectF(offset, offset, diameter, diameter));
    
    m_bkgPart.path.addEllipse(QRectF(offset, offset, diameter, diameter));
}

void ClockBkgWgt::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.setRenderHint(QPainter::TextAntialiasing, true);
    
    painter.fillPath(m_outerFrame.path, m_outerFrame.grad);
    painter.fillPath(m_innerFrame.path, m_innerFrame.grad);
    painter.fillPath(m_bkgPart.path, m_bkgPart.grad);
    
    const qreal radius = qMin(0.5 * width(), 0.5 * height());
    QTransform tf;
    QPen pen(m_timescaleClr);
    
    painter.save();
    for (int i = 0; i < 60; ++i) {
        int len = 6;
        if (0 == (i % 5)) {
            pen.setWidthF(3.0);
        } else {
            pen.setWidthF(1.0);
        }
        
        painter.setPen(pen);
        
        qreal innerRadius = radius - m_outerFrame.width - m_innerFrame.width - 10 - len;
        qreal xPos = radius + innerRadius * qCos(2 * M_PI * 6 * i / 360);
        qreal yPos = radius - innerRadius * qSin(2 * M_PI * 6 * i / 360);
        tf.translate(xPos, yPos);
        tf.rotate(-6 * i);
        painter.setTransform(tf);
        painter.drawLine(QPoint(-len, 0), QPoint(len, 0));
        tf.reset();
    }
    
    pen.setColor(m_timeDigitClr);
    painter.setPen(pen);
    painter.setFont(m_timeDigitFont);
    
    for (int i = 1; i <= 12; ++i) {
        QFontMetrics fm(m_timeDigitFont);
        QString text = QString::number(i);
        
        qreal innerRadius = radius - m_outerFrame.width - m_innerFrame.width - 10 - 36;
        qreal angle = 30 * i - 90;
        qreal xPos = radius + innerRadius * qCos(2 * M_PI * angle / 360);
        qreal yPos = radius + innerRadius * qSin(2 * M_PI * angle / 360);

        tf.translate(xPos, yPos);
        painter.setTransform(tf);
        painter.drawText(-fm.horizontalAdvance(text) / 2, fm.height() / 2 - fm.descent(), text);
        tf.reset();
    }
    
    const QTime &dtCurr = QTime::currentTime();
    tf.translate(radius, radius);
    int h = dtCurr.hour();
    int m = dtCurr.minute();
    int s = dtCurr.second();
    tf.rotate(30 * h - 90 + 0.5 * m);
    painter.setTransform(tf);
    QPainterPath hPath;
    hPath.addRoundedRect(-20, -5, 140, 10, 4, 4);
    painter.fillPath(hPath, Qt::black);
    
    tf.reset();
    tf.translate(radius, radius);
    tf.rotate(6 * m - 90);
    painter.setTransform(tf);
    QPainterPath mPath;
    mPath.addRoundedRect(-20, -4, 200, 8, 4, 4);
    painter.fillPath(mPath, Qt::black);
    
    tf.reset();
    tf.translate(radius, radius);
    tf.rotate(6 * s - 90);
    painter.setTransform(tf);
    QPainterPath sPath;
    sPath.moveTo(-40, 0);
    sPath.lineTo(-36, -4);
    sPath.lineTo(0, -2);
    sPath.lineTo(180, 1.5);
    sPath.lineTo(0, 2);
    sPath.lineTo(-36, 4);
    sPath.lineTo(-40, 0);
    painter.fillPath(sPath, Qt::red);
    
    tf.reset();
    tf.translate(radius, radius);
    QRadialGradient grad;
    grad.setSpread(QGradient::PadSpread);
    grad.setRadius(20);
    grad.setCenter(0, 0);
    grad.setFocalPoint(0, 0);
    grad.setColorAt(0, QColor(220, 220, 230));
    grad.setColorAt(1, QColor(20, 20, 20));
    painter.setTransform(tf);
    painter.setBrush(grad);
    painter.setPen(Qt::transparent);
    painter.drawEllipse(QPoint(0, 0), 10, 10);
    
    painter.restore();
}

void ClockBkgWgt::resizeEvent(QResizeEvent *event)
{
    if (event) {
        const QSize &size = event->size();
        qreal radius = qMin(0.5 * size.width(), 0.5 * size.height());
        
        resetGradient(m_outerFrame.grad, radius);
        resetGradient(m_innerFrame.grad, radius);
        resetGradient(m_bkgPart.grad, radius);
        
        updatePath();
    }
    
    QWidget::resizeEvent(event);
}
