#ifndef CLOCKBKGWGT_H
#define CLOCKBKGWGT_H

#include <QWidget>

class QTimer;

class ClockBkgWgt : public QWidget
{
    Q_OBJECT
public:
    explicit ClockBkgWgt(QWidget *parent = nullptr);
    ~ClockBkgWgt();
    
private:
    void initData();
    void resetGradient(QRadialGradient &grad, qreal radius);
    void updatePath();
    
protected:
    void paintEvent(QPaintEvent *event) Q_DECL_OVERRIDE;
    void resizeEvent(QResizeEvent *event) Q_DECL_OVERRIDE;
    
signals:
    
private:
    // 钟表的局部
    struct SPart {
        QRadialGradient     grad;       // 背景色
        QPainterPath        path;       // 路径
        int                 width;      // 宽度
        
        SPart();
    };

    SPart       m_outerFrame;           // 钟表的外边框
    SPart       m_innerFrame;           // 钟表内边框
    SPart       m_bkgPart;              // 钟表背景部分
    
    QColor      m_timescaleClr;         // 时间刻度颜色
    QColor      m_timeDigitClr;         // 时间数字颜色
    QFont       m_timeDigitFont;        // 时间数字字体
    
    QTimer      *m_timer = nullptr;
};

#endif // CLOCKBKGWGT_H
